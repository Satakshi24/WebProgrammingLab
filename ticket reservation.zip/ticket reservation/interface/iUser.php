<?php 

interface iUser{
	public function loginUser($un, $pwd);
}//end iUser